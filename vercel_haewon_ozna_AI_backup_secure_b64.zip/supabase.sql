create table if not exists matches (
  id bigserial primary key,
  date date not null,
  league text,
  home text not null,
  away text not null,
  home_odds numeric,
  draw_odds numeric,
  away_odds numeric,
  home_goals int,
  away_goals int,
  form_score numeric,
  gf_rolling numeric,
  ga_rolling numeric,
  signal text,
  ou_hint text,
  comment text,
  created_at timestamptz default now()
);
create unique index if not exists uq_match on matches(date, home, away);
alter table matches enable row level security;
do $$
begin
  if not exists (select 1 from pg_policies where tablename='matches' and policyname='public_recent14') then
    create policy public_recent14 on matches
      for select using ( date >= (now() at time zone 'utc')::date - interval '14 days' );
  end if;
end$$;

create table if not exists sec_logs (
  id bigserial primary key,
  ts timestamptz default now(),
  ip text,
  path text,
  status int,
  note text,
  enc jsonb
);
create index if not exists idx_sec_logs_ts on sec_logs(ts desc);
