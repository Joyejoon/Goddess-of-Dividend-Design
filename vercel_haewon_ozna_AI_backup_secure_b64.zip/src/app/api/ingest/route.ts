import { NextRequest, NextResponse } from 'next/server'
import { parse } from 'csv-parse/sync'
import { admin } from '@/lib/supabase'
import { checkIpWhitelist, checkToken, logSecure, checkOrigin } from '@/lib/security'
import { parseBase64Payload } from '@/lib/ingest'

export async function POST(req: NextRequest) {
  // Origin & IP & Token
  const o = checkOrigin(req); if (!o.ok) { await logSecure(req, 403, o.reason); return NextResponse.json({ error: o.reason }, { status: 403 }) }
  const w = checkIpWhitelist(req); if (!w.ok) { await logSecure(req, 403, w.reason); return NextResponse.json({ error: w.reason }, { status: 403 }) }
  const tokenRes = checkToken(req.headers.get('x-ingest-token'), 'INGEST')
  if (!tokenRes.ok) { await logSecure(req, tokenRes.status||401, tokenRes.reason); return NextResponse.json({ error: tokenRes.reason }, { status: tokenRes.status||401 }) }

  const type = (req.headers.get('content-type') || '').toLowerCase()
  let rows: any[] = []

  if (type.includes('application/json')) {
    rows = await req.json()
  } else if (type.includes('text/csv')) {
    const text = await req.text()
    rows = parse(text, { columns: true, skip_empty_lines: true, trim: true })
  } else if (type.includes('application/base64') or type.includes('text/base64')) {
    const b64 = await req.text()
    rows = await parseBase64Payload(b64)
  } else {
    await logSecure(req, 415, 'Unsupported content-type')
    return NextResponse.json({ error: 'Unsupported content-type' }, { status: 415 })
  }

  const db = admin()
  if (!db) { await logSecure(req, 200, 'demo-mode'); return NextResponse.json({ mode: 'demo', received: rows.length }) }

  // Normalize and upsert
  const payload = rows.map((r:any) => ({
    date: r.date,
    league: r.league || null,
    home: r.home, away: r.away,
    home_odds: r.home_odds ?? null, draw_odds: r.draw_odds ?? null, away_odds: r.away_odds ?? null,
    home_goals: r.home_goals ?? null, away_goals: r.away_goals ?? null,
    form_score: r.form_score ?? null, gf_rolling: r.gf_rolling ?? null, ga_rolling: r.ga_rolling ?? null,
    signal: r.signal || null, ou_hint: r.ou_hint || null, comment: r.comment || null
  }))

  const { error } = await db.from('matches').upsert(payload, { onConflict: 'date,home,away' })
  if (error) { await logSecure(req, 500, error.message); return NextResponse.json({ error: error.message }, { status: 500 }) }

  await logSecure(req, 200, `upserted ${payload.length}`)
  return NextResponse.json({ ok: true, upserted: payload.length })
}
