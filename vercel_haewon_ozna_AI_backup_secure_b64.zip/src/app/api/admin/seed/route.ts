import { NextRequest, NextResponse } from 'next/server'
import { admin } from '@/lib/supabase'
import { checkIpWhitelist, checkToken, logSecure, checkOrigin } from '@/lib/security'
export async function POST(req: NextRequest) {
  const o = checkOrigin(req); if (!o.ok) { await logSecure(req, 403, o.reason); return NextResponse.json({ error: o.reason }, { status: 403 }) }
  const w = checkIpWhitelist(req); if (!w.ok) { await logSecure(req, 403, w.reason); return NextResponse.json({ error: w.reason }, { status: 403 }) }
  const tokenRes = checkToken(req.headers.get('x-admin-token'), 'ADMIN')
  if (!tokenRes.ok) { await logSecure(req, tokenRes.status||401, tokenRes.reason); return NextResponse.json({ error: tokenRes.reason }, { status: tokenRes.status||401 }) }
  const db = admin()
  if (!db) { await logSecure(req, 400, 'No DB'); return NextResponse.json({ error: 'No DB configured' }, { status: 400 }) }
  const { error } = await db.from('matches').upsert([{
    date: new Date().toISOString().slice(0,10), league: 'SEED', home: 'Backup', away: 'Restored', signal: 'fav', ou_hint: 'under', comment: 'seeded'
  }], { onConflict: 'date,home,away' })
  if (error) { await logSecure(req, 500, error.message); return NextResponse.json({ error: error.message }, { status: 500 }) }
  await logSecure(req, 200, 'seed ok'); return NextResponse.json({ ok: true })
}
