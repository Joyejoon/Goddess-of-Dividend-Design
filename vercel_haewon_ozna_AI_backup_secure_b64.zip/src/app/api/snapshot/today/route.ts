import { NextRequest, NextResponse } from 'next/server'
import { anon } from '@/lib/supabase'
import { checkOrigin, logSecure } from '@/lib/security'
const demo = [{ date: '2025-08-11', league: 'TEST', home: 'Alpha', away: 'Bravo', signal: 'fav', ou_hint: 'under', comment: 'demo' }]
export async function GET(req: NextRequest) {
  const o = checkOrigin(req); if (!o.ok) { await logSecure(req, 403, o.reason); return NextResponse.json({ error: o.reason }, { status: 403 }) }
  const supa = anon()
  if (!supa) { await logSecure(req, 200, 'demo-mode'); return NextResponse.json({ mode: 'demo', rows: demo }) }
  const today = new Date().toISOString().slice(0,10)
  const { data, error } = await supa.from('matches').select('date,league,home,away,signal,ou_hint,comment').gte('date', today).order('date', { ascending: true }).limit(200)
  if (error) { await logSecure(req, 500, error.message); return NextResponse.json({ error: error.message }, { status: 500 }) }
  await logSecure(req, 200, `rows=${data?.length||0}`)
  return NextResponse.json({ mode: 'live', rows: data })
}
